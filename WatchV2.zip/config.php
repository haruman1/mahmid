<?php

///Jangan hapus tanpa kutip nya(")

///Jangan pernah sekali-sekali jika gak mau error pas php bot.php

///Ganti xxxxxxx dengan data punya kalian

///Capture dulu apk nya ambil data yang di butuhkan

$ticket = "xxxxxxxxxxxxxxxxxx";

$meid = "xxxxxxxxxxxxxxxxxx";

$os="xxxxxxxxxxxxxxxxxx";

$sign="xxxxxxxxxxxxxxxxxx";